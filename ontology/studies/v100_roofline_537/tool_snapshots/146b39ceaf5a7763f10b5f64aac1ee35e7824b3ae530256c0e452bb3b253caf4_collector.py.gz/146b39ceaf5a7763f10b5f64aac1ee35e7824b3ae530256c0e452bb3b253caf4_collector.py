#!/usr/bin/env python3
"""Collect audited, partial first-per-function/launch-shape V100 observations.

Consumes reviewed, freshly staged plans from v100_roofline_prepare.py. This is
profiling evidence, never a replacement for the accepted correctness/timing run.
No shell commands, privileged operations, or historical output directories.
"""
import argparse
import collections
import datetime
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import resource
import shutil
import signal
import subprocess
import time

UUID = 'GPU-c122ecbd-d9f3-18a5-42d4-1535af37e56d'
METRICS = [
    'gpu__time_duration.sum', 'dram__bytes_read.sum', 'dram__bytes_write.sum',
    'dram__bytes.sum', 'dram__bytes.sum.peak_sustained',
    'dram__cycles_elapsed.avg.per_second', 'sm__cycles_elapsed.avg.per_second',
    'lts__t_bytes.sum', 'sm__inst_executed_pipe_tensor.sum',
] + ['smsp__sass_thread_inst_executed_op_' + x + '_pred_on.sum'
     for x in ('hadd', 'hmul', 'hfma', 'fadd', 'fmul', 'ffma', 'dadd', 'dmul', 'dfma')
] + ['sm__sass_thread_inst_executed_op_' + x + '_pred_on.sum.peak_sustained'
     for x in ('hfma', 'ffma', 'dfma')]


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for data in iter(lambda: f.read(4 * 1024**2), b''):
            h.update(data)
    return h.hexdigest()


def dump(path, obj):
    tmp = path.with_suffix(path.suffix + '.new')
    tmp.write_text(json.dumps(obj, indent=2, allow_nan=False) + '\n')
    tmp.replace(path)


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def bindings(plan):
    changed = [p for p, expected in plan['execution_bindings'].items()
               if not Path(p).is_file() or sha(p) != expected]
    if sha(plan['reference_result']) != plan['reference_result_sha256']:
        changed.append(plan['reference_result'])
    if changed:
        raise RuntimeError('Bound evidence changed: ' + repr(changed))


def idle_snapshot():
    query = subprocess.run(['nvidia-smi', '--query-compute-apps=gpu_uuid,pid,process_name',
                            '--format=csv,noheader,nounits'], text=True,
                           capture_output=True, check=True)
    processes = query.stdout
    if any(line.split(',')[0].strip() == UUID for line in processes.splitlines()):
        raise RuntimeError('GPU6 has an existing compute process; refuse execution: ' + processes)
    device = subprocess.run(['nvidia-smi', '-i', '6',
        '--query-gpu=uuid,name,driver_version,memory.total,memory.used,clocks.current.sm,clocks.current.memory,power.draw,ecc.mode.current',
        '--format=csv'], text=True, capture_output=True, check=True).stdout
    if UUID not in device:
        raise RuntimeError('GPU6 UUID differs from protocol')
    return {'time': utc(), 'gpu': device, 'compute_processes': processes}


def limits():
    # New profiler auxiliary files are bounded. No accepted capture is touched.
    resource.setrlimit(resource.RLIMIT_FSIZE, (1024**3, 1024**3))


def run(command, env, cwd, log, timeout, reserve):
    began = time.monotonic()
    with log.open('wb') as out:
        process = subprocess.Popen(command, cwd=cwd, env=env, stdout=out,
                                   stderr=subprocess.STDOUT, start_new_session=True,
                                   preexec_fn=limits)
        stop_reason = None
        while process.poll() is None:
            if time.monotonic() - began > timeout:
                stop_reason = 'wall_timeout'
            elif shutil.disk_usage(cwd).free < reserve:
                stop_reason = 'scratch_free_space_reserve'
            if stop_reason:
                # Only the fresh session created above; never discover/kill by name.
                if os.getsid(process.pid) != process.pid:
                    raise RuntimeError('Own child session guard failed')
                os.killpg(process.pid, signal.SIGTERM)
                try:
                    process.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    if os.getsid(process.pid) != process.pid:
                        raise RuntimeError('Own child session guard failed')
                    os.killpg(process.pid, signal.SIGKILL)
                break
            time.sleep(0.5)
        code = process.wait()
    return {'returncode': code, 'stop_reason': stop_reason,
            'wall_seconds': time.monotonic() - began, 'log_sha256': sha(log)}


def collect(plan_path, root, timeout, reserve_mib, retain_auxiliary):
    plan = json.loads(plan_path.read_text())
    if plan['blocking_gates'] or not plan.get('staged'):
        return {'plan': str(plan_path), 'status': 'not_executed_plan_blocked_or_not_staged'}
    slot = plan_path.parent
    if (slot / 'profile_provenance.json').exists():
        return {'plan': str(plan_path), 'status': 'existing_profile_preserved'}
    scratch = Path(plan['scratch_cwd']).resolve()
    scratch.relative_to(slot.resolve())
    scratch.relative_to(Path('/tmp'))
    if not scratch.is_dir() or scratch.stat().st_uid != os.getuid():
        raise RuntimeError('Scratch ownership/staging check failed')
    if plan['environment_overrides']['CUDA_VISIBLE_DEVICES'] != '6':
        raise RuntimeError('Only reviewed physical GPU6 is supported')
    env = os.environ.copy()
    env.update(plan['environment_overrides'])
    env['CUDA_VISIBLE_DEVICES'] = '6'
    # NCU's injected process needs Julia's bundled C++ runtime as well as libjulia.
    julia = Path('/home/imo/.julia/juliaup/julia-1.12.6+0.x64.linux.gnu')
    env['LD_LIBRARY_PATH'] = str(julia/'lib/julia') + ':' + str(julia/'lib') + ':' + env.get('LD_LIBRARY_PATH', '')
    command = list(plan['profile_target_command'])
    if command[0] == 'julia':
        command[0] = '/home/imo/.juliaup/bin/julia'
    csv_path = slot / 'counters.csv'
    ncu = ['ncu', '--target-processes', 'all', '--filter-mode', 'per-launch-config',
           '--kernel-id', '::regex:.*:1', '--clock-control', 'none', '--cache-control', 'all',
           '--metrics', ','.join(METRICS), '--csv', '--page', 'raw',
           '--print-units', 'base', '--log-file', str(csv_path)] + command
    provenance = {'schema_version': 1, 'started_at': utc(), 'plan': str(plan_path),
        'plan_sha256': sha(plan_path), 'collector_sha256': sha(__file__),
        'command': ncu, 'environment_overrides': {**plan['environment_overrides'],
            'LD_LIBRARY_PATH': env['LD_LIBRARY_PATH']}, 'gpu_uuid': UUID,
        'selector_scope': 'first_invocation_per_function_and_launch_geometry; partial kernel sample',
        'ROI_coverage': 'unreviewed_partial; warmup/setup/validation may be present',
        'primary_contract_unchanged': True,
        'profiling_auxiliary_retention': 'kept' if retain_auxiliary else
            'Fresh scratch only removed after manifest; not a correctness certificate. Raw counters, logs, provenance retained.',
        'status': 'started'}
    dump(slot/'profile_provenance.json', provenance)
    try:
        with Path('/tmp/hecbench-julia-study-gpu.lock').open('a') as lock:
            fcntl.flock(lock, fcntl.LOCK_EX)
            bindings(plan)
            provenance['device_before'] = idle_snapshot()
            if shutil.disk_usage(scratch).free < reserve_mib * 1024**2:
                raise RuntimeError('Free space below reserve')
            if plan['build_command']:
                provenance['build'] = run(plan['build_command'], env, scratch,
                    slot/'build.log', timeout, reserve_mib*1024**2)
                if provenance['build']['returncode'] != 0:
                    raise RuntimeError('Isolated build failed; see retained build log')
            # Build may create a GPU context; require a second idle check.
            provenance['device_immediately_before_profile'] = idle_snapshot()
            provenance['profiler_version'] = subprocess.run(['ncu', '--version'],
                capture_output=True, text=True, check=True).stdout
            provenance['profile'] = run(ncu, env, scratch, slot/'execution.log',
                                        timeout, reserve_mib*1024**2)
            bindings(plan)
            provenance['binding_recheck_after'] = 'unchanged'
            provenance['status'] = ('profile_process_completed' if provenance['profile']['returncode'] == 0
                                    else 'profile_process_failed')
            if csv_path.is_file():
                provenance['counters_sha256'] = sha(csv_path)
                parser_path = root/'tools/v100_roofline_classify.py'
                loader = importlib.util.spec_from_file_location('roofline_parser', parser_path)
                parser = importlib.util.module_from_spec(loader)
                loader.loader.exec_module(parser)
                try:
                    groups, csv_sha = parser.read_csv(csv_path)
                    context = {k: plan[k] for k in ('benchmark','model','configuration_id','reference_result_sha256')}
                    context.update(ROI_stage='unassigned', ROI_coverage='partial_first_function_geometry',
                                   first_invocation_may_be_warmup=True)
                    records = [parser.derive(g, context=context) for g in groups]
                    derived = {'schema_version': 1, 'input_csv': str(csv_path),
                        'input_sha256': csv_sha, 'parser_sha256': sha(parser_path),
                        'kernel_count': len(records), 'records': records,
                        'benchmark_bottleneck': 'not_aggregated',
                        'raw_metrics': groups}
                    dump(slot/'derived.json', derived)
                    provenance['kernel_count'] = len(records)
                except (ValueError, KeyError) as error:
                    provenance['counter_parse_error'] = str(error)
    except Exception as error:
        provenance['status'] = 'collection_failed'
        provenance['error'] = str(error)
    finally:
        manifest = []
        for path in sorted(scratch.rglob('*')):
            if path.is_file() and not path.is_symlink():
                manifest.append({'path': str(path.relative_to(scratch)),
                                 'bytes': path.stat().st_size, 'sha256': sha(path)})
        dump(slot/'profiling_auxiliary_manifest.json', manifest)
        provenance['auxiliary_manifest_sha256'] = sha(slot/'profiling_auxiliary_manifest.json')
        if not retain_auxiliary:
            shutil.rmtree(scratch)
        provenance['finished_at'] = utc()
        dump(slot/'profile_provenance.json', provenance)
    # Root is the only measurement-field writer. Never call this from parallel GPU workers.
    ledger = root/'ontology/studies/v100_roofline_537/benchmarks'/ (plan['benchmark']+'.json')
    data = json.loads(ledger.read_text())
    model = data['models'][plan['model']]
    model.update(profiling_status=provenance['status'],
        profile_ids=[str(slot/'profile_provenance.json')],
        profile_provenance_sha256=sha(slot/'profile_provenance.json'),
        sampled_kernel_count=provenance.get('kernel_count',0),
        roi_coverage='partial_first_function_geometry_unreviewed',
        roofline_position=None, roofline_region=None, observed_bottleneck=None,
        reason='Kernel observations require stage mapping; no whole-ROI bottleneck is inferred.')
    if (slot/'derived.json').exists():
        model['kernel_observations']={'path':str(slot/'derived.json'),'sha256':sha(slot/'derived.json')}
    dump(ledger,data)
    return {'benchmark':plan['benchmark'],'model':plan['model'],
            'status':provenance['status'],'kernels':provenance.get('kernel_count',0),
            'error':provenance.get('error')}


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--source-root',type=Path,required=True)
    ap.add_argument('--plan-root',type=Path,required=True)
    ap.add_argument('--timeout',type=int,default=300)
    ap.add_argument('--reserve-mib',type=int,default=2048)
    ap.add_argument('--retain-auxiliary',action='store_true')
    a=ap.parse_args()
    for p in sorted(a.plan_root.glob('*/*/plan.json')):
        result=collect(p,a.source_root,a.timeout,a.reserve_mib,a.retain_auxiliary)
        print(json.dumps(result),flush=True)


if __name__=='__main__':
    main()
